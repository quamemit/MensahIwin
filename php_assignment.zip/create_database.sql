-- Create the database
CREATE DATABASE school;

-- Use the database
USE school;

-- Create the student table
CREATE TABLE student (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    index_number VARCHAR(50) UNIQUE NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    password VARCHAR(255) NOT NULL
);
