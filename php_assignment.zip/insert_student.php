<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "school";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$index_number = $_POST['index_number'];
$gender = $_POST['gender'];
$password_input = $_POST['password'];

$hashed_password = password_hash($password_input, PASSWORD_DEFAULT);

$sql = "INSERT INTO student (name, index_number, gender, password) 
        VALUES ('$name', '$index_number', '$gender', '$hashed_password')";

if ($conn->query($sql) === TRUE) {
    echo "New student record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>